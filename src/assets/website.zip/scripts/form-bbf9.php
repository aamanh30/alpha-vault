<?php

require_once('FormProcessor.php');

$form = array(
    'subject' => 'Invest Enquiry - Alpha Vault',
    'email_message' => 'You have a new form submission',
    'success_redirect' => '',
    'sendIpAddress' => true,
    'email' => array(
    'from' => 'ishaan@rgbops.com',
    'to' => 'ishaan@rgbops.com'
    ),
    'fields' => array(
    'name' => array(
    'order' => 1,
    'type' => 'string',
    'label' => 'Name',
    'required' => true,
    'errors' => array(
    'required' => 'Field \'Name\' is required.'
    )
    ),
    'email' => array(
    'order' => 2,
    'type' => 'email',
    'label' => 'Email',
    'required' => true,
    'errors' => array(
    'required' => 'Field \'Email\' is required.'
    )
    ),
    'phone' => array(
    'order' => 3,
    'type' => 'tel',
    'label' => 'Phone',
    'required' => true,
    'errors' => array(
    'required' => 'Field \'Phone\' is required.'
    )
    ),
    'text' => array(
    'order' => 4,
    'type' => 'string',
    'label' => 'text',
    'required' => false,
    'errors' => array(
    'required' => 'Field \'text\' is required.'
    )
    ),
    'message' => array(
    'order' => 5,
    'type' => 'string',
    'label' => 'Message',
    'required' => true,
    'errors' => array(
    'required' => 'Field \'Message\' is required.'
    )
    ),
    'agree' => array(
    'order' => 6,
    'type' => 'checkbox',
    'label' => 'What is your range of investment *',
    'required' => false,
    'errors' => array(
    'required' => 'Field \'What is your range of investment *\' is required.'
    )
    ),
    'checkbox' => array(
    'order' => 7,
    'type' => 'checkbox',
    'label' => '&lt; $25,000',
    'required' => false,
    'errors' => array(
    'required' => 'Field \'&lt; $25,000\' is required.'
    )
    ),
    'checkbox-1' => array(
    'order' => 8,
    'type' => 'checkbox',
    'label' => ' &lt; $50,000',
    'required' => false,
    'errors' => array(
    'required' => 'Field \' &lt; $50,000\' is required.'
    )
    ),
    'checkbox-2' => array(
    'order' => 9,
    'type' => 'checkbox',
    'label' => '&lt; $100,000',
    'required' => false,
    'errors' => array(
    'required' => 'Field \'&lt; $100,000\' is required.'
    )
    ),
    'checkbox-3' => array(
    'order' => 10,
    'type' => 'checkbox',
    'label' => '&lt; $25,0000',
    'required' => false,
    'errors' => array(
    'required' => 'Field \'&lt; $25,0000\' is required.'
    )
    ),
    )
    );

    $processor = new FormProcessor();
    $processor->process($form);

    ?>